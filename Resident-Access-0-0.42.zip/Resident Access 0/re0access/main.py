"""Resident Access 0: a screen reader companion for Resident Evil 0 HD Remaster (Steam).

It runs next to the game, reads its memory and the text the controller add-on passes on, and
speaks through your screen reader (or Windows' own voice). Early builds: it finds the game,
makes the controller add-on work with Steam Input, reads the game's messages and menus, and
says where you are as you move between rooms, and has the room list (doors, items, things to
check, enemies), auto walk and the 3D beacon from Resident Access HD (see roomlist.py).
"""
import ctypes
import logging
import math
import re
import logging.handlers
import os
import time

from .game import Game, scene_words
from . import text as T
from . import gmd
from .link import Link
from . import link as L
from .mem import Memory, NotReady
from .speech import Speech
from .version import VERSION
from .roomlist import RoomList
from .modmenu import ModMenu

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
LOG = os.path.join(ROOT, "re0access.log")
SETTINGS = os.path.join(ROOT, "settings.json")
QUIT_EVENT = "Local\\ResidentAccess0Quit"


class App(RoomList, ModMenu):
    quit_event = None

    def __init__(self):
        self.speech = Speech()
        self.mem = Memory()
        self.game = Game(self.mem)
        self.link = Link()
        self.connected = False
        self.scene = None
        self.pad_state = None
        self.pad_tries = 0
        self.prev_buttons = 0
        self.text_seen = {}         # string -> when last laid out
        self.text_quiet_until = 0.0
        self.long_said = {}
        self.init_list()
        self.init_menu(SETTINGS)

    # Pictures the game shows with some words: what they show, said after the words.
    PICTURES = [
        # (the Microfilm Image file's last page, and the projector with both microfilms in)
        (("numbers appear on the seats", "something written on top of the picture of the seats"),
         "Picture: the conference room's seats seen from above, the front of the room, with the "
         "lectern and screen, at the top. Four rows of four seats, two each side of the middle "
         "aisle, each with a number or letter on it. Front row, left to right: 0, 1, 2, 3. "
         "Second row: 4, 5, 6, 7. Third row: 8, 9, A, B. Back row: C, D, E, F."),
    ]

    def say(self, text, interrupt=False):
        if not text:
            return
        low = text.lower()
        for keys, picture in self.PICTURES:
            if any(k in low for k in keys) and picture not in text:
                text = "%s %s" % (text, picture)
                break
        logging.info("say: %s", text)
        try:
            self.speech.say(text, interrupt=interrupt)
        except Exception:
            logging.exception("speech")

    # -- the controller fix ------------------------------------------------------------------
    def poll_pad_fix(self):
        if self.pad_state in ("fixed", "done") or self.pad_tries > 600:
            return
        self.pad_tries += 1
        st = self.game.fix_pad()
        if st != self.pad_state:
            logging.info("controller fix: %s", st)
            self.pad_state = st

    # -- rooms -------------------------------------------------------------------------------
    def poll_room(self):
        no = self.game.scene()
        if no is None or no == self.scene:
            self.scene_pending = None
            return
        first = self.scene is None
        if not first and self.scene_fits(no) is False:
            # (another room loaded for an event while you stay put: not a room change; taken
            # as one only if it lasts)
            pend = getattr(self, "scene_pending", None)
            if not pend or pend[0] != no:
                self.scene_pending = (no, time.monotonic())
                logging.info("scene %s loaded but you are not in it", no)
                return
            if time.monotonic() - pend[1] < 15.0:
                return
        self.scene_pending = None
        self.scene = no
        if not self.game.characters():
            return                      # (title screen, or a scene still loading)
        self.say(scene_words(no), interrupt=not first)
        self.target = None
        if self.walker.walking:
            self.stop_walk()
        try:
            self.load_room()
        except Exception:
            logging.exception("room")

    def where_words(self):
        chars = self.game.characters()
        if self.scene is None or not chars:
            return "Not in the game."
        names = " and ".join(n for n, _ in chars)
        return "%s. %s here." % (scene_words(self.scene), names)

    # -- the game's text ----------------------------------------------------------------
    # Strings the game lays out are passed on by the controller add-on (it catches the game's
    # text layout). Most are drawn again every frame while they are on screen, so a string is
    # said when it appears, and again only after it has been gone for a moment.
    GONE = 0.6

    SLOT_LABEL = re.compile(r"^\s*(\d+)\.$")

    def poll_text(self):
        now = time.monotonic()
        fresh = []
        batch = self.link.texts()
        for _, _, raw in batch:
            # A question's answers are named in its text: <SEL Yes_No_Use>
            m = re.search(r"<SEL ([A-Za-z_]+)>", raw)
            if m:
                self.choice_words = [w if w.isupper() else re.sub(r"(?<=[a-z])(?=[A-Z])", " ", w).capitalize()
                                     for w in m.group(1).split("_")]      # ("HourHand": "Hour hand")
                self.question_at = now
                self.question_text = raw
                low = raw.lower()
                if "minute hand" in low or "hour hand" in low:
                    # (setting the clock: its time is said after the question, and as it changes)
                    if now - getattr(self, "clock_at", -99.0) > 30.0:
                        self.clock_said = None
                    self.clock_at = now
        if now - getattr(self, "clock_at", -99.0) < 120.0:
            # (setting the clock: its buttons L, R, Hour hand, OK are said only as the cursor moves
            # onto them, not all at once when they appear)
            batch = [b for b in batch if T.clean(b[2]) not in ("L", "R", "Hour hand", "Minute hand", "OK",
                                                                "Hour hand OK", "Minute hand OK")]
        words = [T.clean(raw) for _, _, raw in batch]
        if "Continue" in words and "Restart" in words:
            # (a slot picked on the load list: Continue / Restart / Back, the cursor a picture)
            self.load_choices = ["Continue", "Restart", "Back"]
            self.load_choice_was = None
        elif getattr(self, "load_choices", None) and any(self.SLOT_LABEL.match(w) for w in words):
            self.load_choices = None
        if self.slot_list_up(batch):
            self.read_slots(batch, now)
            return
        reading = self.game.file_reader()
        if reading is not None and self.game.files_screen() is not None:
            return          # (a file read from the Files page: poll_files reads it, page by page)
        if reading is not None:
            self.read_file_page(batch, reading)
            return
        self.reader_file = None
        # (a line with a name in it - "<P_BI>'s shoulders" - has the game lay the name out on its
        # own as well: said in the line, not again after it)
        named = {"Billy" for _c, _h, r in batch if "<P_BI>" in r} | {"Rebecca" for _c, _h, r in batch if "<P_RE>" in r}
        for caller, holder, raw in batch:
            self.note_text(T.clean(raw), now)
            if "Set number" in raw:
                seen = self.text_seen.get(raw)
                if seen is None or now - seen >= self.GONE:
                    self.dial_hint = now    # (the combination dials put up: look for them)
            last = self.text_seen.get(raw)
            self.text_seen[raw] = now
            if last is not None and now - last < self.GONE:
                continue
            if now < self.text_quiet_until:
                continue            # (what was already on screen when the mod started)
            if raw.startswith(("<B_DE>", "<B_CA>", "<B_")) or raw.startswith("<ICON"):
                continue            # the button hints at the bottom of a screen
            words = T.clean(raw)
            if words.startswith(":"):
                continue            # (":Change number", ":All": the buttons, said with the number)
            if self.note_text(words, now):
                continue            # (the mod is speaking its own row of the Option menu)
            if len(words) < 2 or words in fresh or words in named:
                continue
            if len(words) > 60:
                # (a file's pages are laid out again as you turn them, the last one with the
                # next: a long text is said once in a while)
                said = self.long_said.get(words)
                if said is not None and now - said < 60:
                    continue
                self.long_said[words] = now
            fresh.append(self.whose_items(self.with_equip(self.with_amount(words), words)))
        if len(self.text_seen) > 3000:
            self.text_seen = {k: v for k, v in self.text_seen.items() if now - v < 30}
        fresh = self.fill_item_name(fresh)
        if not any("?" in w for w in fresh):
            fresh = [w for w in fresh if w not in ("Yes", "No")]
        if fresh:
            # (a dialog the game keeps laid out out of sight shows just "Yes" and "No": a real
            # question comes with its words)
            # (a menu's choice just said comes first: its description follows it)
            self.say(" ".join(fresh), interrupt=time.monotonic() - getattr(self, "menu_said", 0) > 0.8)

    def read_file_page(self, batch, page):
        """A file picked up is read a page at a time (the game lays out the pages either side as
        well, for turning): say the page the game is on, from the file's own text."""
        gd = self.game_dir()
        if not gd:
            return
        from .gmd import file_pages
        if getattr(self, "reader_file", None) is None:
            said = [T.clean(raw) for caller, holder, raw in batch]
            for exact in (True, False):
                for item in range(150, 181):
                    pages = file_pages(gd, item)
                    if not pages:
                        continue
                    if exact and pages[0] in said or \
                            not exact and any(len(w) > 25 and any(w in pg for pg in pages) for w in said):
                        self.reader_file = item
                        self.reader_page = None
                        break
                if getattr(self, "reader_file", None):
                    break
        item = getattr(self, "reader_file", None)
        if item is None or page == getattr(self, "reader_page", None):
            return
        self.reader_page = page
        pages = file_pages(gd, item)
        if 0 <= page < len(pages):
            self.say("%s%s" % (pages[page], " (last page)" if page == len(pages) - 1 else ""), interrupt=True)

    def poll_choice(self):
        """Yes and No (and Use) under a question in the message window are pictures: say the one
        the cursor is on as it moves."""
        asked = time.monotonic() - getattr(self, "question_at", -99.0) <= 60.0
        cur = self.game.message_choice(expect=asked)
        # (the window waits the same way at the end of any message: only a question just asked
        # has answers to say)
        if cur is not None and not asked:
            cur = None
        if cur is None and getattr(self, "choice_was", None) is not None:
            self.question_at = -99.0        # (that question is over)
            if self.choice_was == 0 and "lever" in getattr(self, "question_text", "").lower():
                self.start_holding()
            self.panel_answer(getattr(self, "question_text", "").lower(), self.choice_was)
        if cur is not None:
            self.game.save_row()        # (finds the save list ahead of time, for the typewriter)
        was = getattr(self, "choice_was", None)
        self.choice_was = cur
        if cur is None or cur == was:
            return
        words = getattr(self, "choice_words", None) or ["Yes", "No"]
        if was is None and time.monotonic() - getattr(self, "clock_at", -99.0) < 120.0:
            return      # (the clock's buttons: said only as the cursor moves)
        if cur < len(words):
            # (the first one comes after the question itself)
            self.say(words[cur], interrupt=was is not None)

    # The Torture Room's power supply panel: five switches, each Up adds its volts to the meter
    # and Down takes them away; the meter has to read 70. (The small gauge over each switch shows
    # how many volts it is worth: 30, 20, 40, 10, 50 - up, up, down, up, up makes 70.)
    PANEL_VOLTS = [30, 20, 40, 10, 50]
    ORDINALS = ["first", "second", "third", "fourth", "fifth"]

    def panel_answer(self, q, answer):
        """A question at the panel answered: say what it did to the meter."""
        if "adjust the panel" in q:
            if answer == 0:
                self.panel_volts = 0
                self.say("Power panel. The meter reads 0 and has to read 70. Press A, then flip the "
                         "switches 1 to 5 in turn, Up adds, Down takes away: switch 1 is worth 30 volts, "
                         "2 is 20, 3 is 40, 4 is 10, 5 is 50.", interrupt=False)
            return
        m = re.search(r"flip the (first|second|third|fourth|fifth) switch", q)
        if not m:
            return
        n = self.ORDINALS.index(m.group(1))
        if n == 0 or getattr(self, "panel_volts", None) is None:
            self.panel_volts = 0
        if answer == 2:
            self.panel_volts = None
            self.say("Cancelled.", interrupt=False)
            return
        if answer not in (0, 1):
            return
        # (the meter stops at 0 and at 100: down from 0 leaves it at 0, and the next switch up
        # counts from there - switch 1 down then 2 up reads 20)
        self.panel_volts = max(0, min(100, self.panel_volts + self.PANEL_VOLTS[n] * (1 if answer == 0 else -1)))
        v = self.panel_volts
        words = "Switch %d %s. %d volts." % (n + 1, "up" if answer == 0 else "down", v)
        if n == 4:
            words += " That's 70." if v == 70 else " Not 70: try again."
            if v == 70:
                self.story_moves = ("Rebecca", 0x5B)    # (she falls into the chasm under the Storage Room)
            self.panel_volts = None
        else:
            words += " Need 70."
        self.say(words, interrupt=False)

    def poll_clock(self):
        """Setting the clock's hands: say the time it shows when asked which hand to turn, and
        again whenever a hand moves."""
        if time.monotonic() - getattr(self, "clock_at", -99.0) > 120.0:
            return
        if self.game.message_choice() is None:
            return
        hands = self.game.clock_hands()
        if hands is None or hands == getattr(self, "clock_said", None):
            return
        first = getattr(self, "clock_said", None) is None
        self.clock_said = hands
        h, m = hands
        words = "%d:%02d" % (h or 12, m * 5)
        self.say(("The clock shows %s." % words) if first else words, interrupt=not first)

    def start_holding(self):
        """Yes to pulling a lever: the character holds it until they move away."""
        c = self.game.controlled()
        if not c:
            return
        pos = self.game.pos(c[1])
        if not pos:
            return
        self.holding = (c[0], c[1], pos, time.monotonic())
        self.say("Holding.", interrupt=False)

    def poll_hold(self):
        h = getattr(self, "holding", None)
        if not h:
            return
        name, obj, pos, since = h
        now_pos = self.game.pos(obj)
        if not now_pos:
            self.holding = None
            return
        if time.monotonic() - since < 6.0:
            self.holding = (name, obj, now_pos, since)     # (pulling it moves them a little, and shows the lock)
            return
        if math.hypot(now_pos[0] - pos[0], now_pos[2] - pos[2]) > 12.0:
            self.holding = None
            c = self.game.controlled()
            who = "" if c and c[0] == name else name + " "
            self.say("%slet go." % who if who else "Let go.", interrupt=True)

    GAP = re.compile(r"\b(the|a|an)\s*([?.!])")

    def fill_item_name(self, fresh):
        """"Take the ?" and "You got the ." have the item's name laid out on its own: put it in
        its place ("Take the Handgun Ammo?")."""
        names = set(self.item_names() or [])
        for i, w in enumerate(fresh):
            m = self.GAP.search(w)
            if not m:
                continue
            for j, other in enumerate(fresh):
                base = other.split(",")[0]
                if j != i and base in names:
                    # (the name alone: the amount added for your own items is not this one's)
                    fresh[i] = w[:m.start()] + m.group(1) + " " + base + m.group(2) + w[m.end():]
                    del fresh[j]
                    return fresh
        return fresh

    # -- the title screen's menus (pictures, not text) ----------------------------------
    def poll_title(self):
        tm = self.game.title_menu()
        key = tm[:2] if tm else None
        if key != getattr(self, "title_seen", None):
            self.title_seen = key
            if tm and tm[2]:
                self.say_menu(tm[2])
        self.poll_setup(tm)

    def say_menu(self, words):
        self.menu_said = time.monotonic()
        self.say(words, interrupt=True)

    def poll_setup(self, tm):
        from .game import SETUP_ROWS, TITLE_SETUP
        st = self.game.setup() if tm and tm[0] == TITLE_SETUP else None
        was = getattr(self, "setup_seen", None)
        self.setup_seen = st
        if not st:
            return
        row, vals = st
        name, choices = SETUP_ROWS[row]
        if was is None or was[0] != row:
            self.say_menu("%s: %s" % (name, choices[vals[row]]))
        elif was[1][row] != vals[row]:
            self.say_menu(choices[vals[row]])

    # -- the save / load slots ------------------------------------------------------------
    def slot_list_up(self, batch=()):
        from .game import TITLE_LOAD
        tm = self.game.title_menu()
        if tm and tm[0] == TITLE_LOAD:
            return True
        # In play, the typewriter's save list: its slots are laid out as "1.", "2." ...
        if tm is None:
            now = time.monotonic()
            if any(self.SLOT_LABEL.match(T.clean(raw)) for _, _, raw in batch):
                if now > getattr(self, "save_watch_until", 0.0):
                    self.slot_said = None                # (the list newly opened)
                self.save_list_until = now + 2.0
                self.save_watch_until = now + 120.0     # (poll_save says the slot as the cursor moves)
            return now < getattr(self, "save_list_until", 0.0)
        return False

    def read_slots(self, batch, now):
        """The slot list is laid out again as it scrolls: keep what each slot says, and say just
        the slot the cursor is on."""
        slots = getattr(self, "slots", None)
        if slots is None:
            slots = self.slots = {}
        cur = None
        for caller, holder, raw in batch:
            self.text_seen[raw] = now
            words = T.clean(raw)
            mm = self.SLOT_LABEL.match(words)
            if mm:
                cur = int(mm.group(1))
                slots[cur] = []
            elif cur is not None and words and not raw.startswith(("<B_", "<ICON")):
                slots[cur].append(words)
        idx = self.game.save_row()
        if idx is None or idx + 1 not in slots:
            if idx is not None and idx != getattr(self, "slot_missing", None):
                self.slot_missing = idx
                logging.info("slot %s not laid out yet (have %s)", idx + 1, sorted(slots))
            return
        n = idx + 1
        key = (n, tuple(slots[n]))
        if key == getattr(self, "slot_said", None):
            return
        self.slot_said = key
        self.say("Slot %d: %s" % (n, ", ".join(slots[n]) or "No Data"), interrupt=True)

    def poll_save(self):
        """The typewriter's save list: moving the cursor does not lay its slots out again, so
        follow the cursor and say the slot it is on (from what was laid out)."""
        now = time.monotonic()
        if now > getattr(self, "save_watch_until", 0.0):
            return
        idx = self.game.save_row()
        if idx is None:
            return
        slots = getattr(self, "slots", None) or {}
        n = idx + 1
        if n not in slots:
            return
        key = (n, tuple(slots[n]))
        if key == getattr(self, "slot_said", None):
            return
        self.slot_said = key
        self.save_watch_until = now + 120.0
        self.say("Slot %d: %s" % (n, ", ".join(slots[n]) or "No Data"), interrupt=True)

    def poll_load_choice(self):
        """Continue / Restart / Back after picking a slot to load: say the one the cursor is on."""
        ch = getattr(self, "load_choices", None)
        if not ch:
            return
        from .game import TITLE_LOAD
        tm = self.game.title_menu()
        cur = self.game.save_choice()
        if (tm is not None and tm[0] != TITLE_LOAD) or cur is None or not 0 <= cur < len(ch):
            if cur is None or (tm is not None and tm[0] != TITLE_LOAD):
                self.load_choices = None
            return
        if cur != getattr(self, "load_choice_was", None):
            first = getattr(self, "load_choice_was", None) is None
            self.load_choice_was = cur
            self.say_menu(("Load: " if first else "") + ch[cur])

    # -- the brake's number pad --------------------------------------------------------
    # Keys 1 to 9 in rows of three (1 2 3 / 4 5 6 / 7 8 9), the cursor starting on 5. The cursor is
    # a picture: follow it from the D-pad (and the stick), and set it right from each number put in.
    def poll_brake(self):
        from . import link as L
        rd = getattr(self, "room_data", None)
        look = bool(rd) and any(t.kind == "check" and any(w in t.name.lower() for w in ("brake", "panel", "card"))
                                                  for t in rd.things)
        pad = self.game.brake_pad(look=look)
        st = getattr(self, "brake", None)
        now = time.monotonic()
        pm = self.game.pause_menu()
        paused = bool(pm and pm[0] != 0)
        if pad is None:
            if st:
                # (gone: closed, or only hidden behind the Start menu; kept a while to tell which)
                st.setdefault("lost", now)
                st["paused"] = st.get("paused") or paused
                if now - st["lost"] > 120.0:
                    self.brake = None
            return
        target, total = pad
        if st and "lost" in st:
            if st.get("paused") and st["target"] == target and now - st["lost"] < 120.0:
                del st["lost"]                      # (back from the Start menu: same pad, same cursor)
                st.pop("paused", None)
            else:
                st = self.brake = None              # (closed and opened again: the cursor back on 5)
        real = self.link.real()
        buttons = real.get("buttons", 0)
        lx, ly = real.get("lx", 0), real.get("ly", 0)
        dirs = buttons & (L.UP | L.DOWN | L.LEFT | L.RIGHT)
        if lx > 20000: dirs |= L.RIGHT
        elif lx < -20000: dirs |= L.LEFT
        if ly > 20000: dirs |= L.UP
        elif ly < -20000: dirs |= L.DOWN
        if st is None:
            st = self.brake = {"key": 5, "total": total, "count": 0, "held": dirs, "target": target,
                               "a": bool(buttons & L.A), "sum": total, "own": False, "pending": []}
            self.say("Number pad. Put in 10 numbers that add up to %d. Total %d. On 5." % (target, total),
                     interrupt=True)
            return
        pressed = dirs & ~st["held"]
        st["held"] = dirs
        a_now = bool(buttons & L.A)
        a_pressed = a_now and not st["a"]
        st["a"] = a_now
        if paused:
            return                                  # (the Start menu takes the D-pad)
        if pressed:
            r, c = divmod(st["key"] - 1, 3)
            if pressed & L.UP: r = (r - 1) % 3          # (the cursor wraps round at the edges)
            elif pressed & L.DOWN: r = (r + 1) % 3
            elif pressed & L.LEFT: c = (c - 1) % 3
            elif pressed & L.RIGHT: c = (c + 1) % 3
            st["key"] = r * 3 + c + 1
            self.say(str(st["key"]), interrupt=True)
        if a_pressed and st["count"] < 10:
            st["pending"].append((now, st["key"]))
        if total != st["total"]:
            # (the rear pad shows its total: go by that, and by it set the cursor right)
            d = total - st["total"]
            st["total"] = total
            st["pending"] = []
            if 1 <= d <= 9:
                st["count"] += 1
                st["key"] = d                       # (the key just pressed is where the cursor is)
            elif d < 0 and total > 0:
                st["count"] = max(0, st["count"] - 1)
            elif total == 0:
                st["count"] = 0
            st["sum"] = total
            self.say(self.brake_words(st), interrupt=True)
        elif st["pending"] and now - st["pending"][0][0] > 0.8:
            # (the front pad's screen is broken, its total never shown: add up the keys pressed)
            _, key = st["pending"].pop(0)
            st["own"] = True
            st["count"] += 1
            st["sum"] += key
            self.say(self.brake_words(st, key), interrupt=True)
        if target != st["target"]:
            st["target"] = target
            self.say("Target %d." % target)

    # -- the combination dials (the Duralumin Case) ------------------------------------------
    DIAL_NAMES = ("Left", "Middle", "Right")

    def poll_dial(self):
        hint = getattr(self, "dial_hint", None)
        now = time.monotonic()
        st = getattr(self, "dial", None)
        look = hint is not None and now - hint < 30.0
        got = self.game.dial_lock(look=look)
        if got is None:
            if st and now - st["seen"] > 3.0:
                self.dial = None
            return
        pick, nums = got
        if st is None or (hint is not None and hint > st["opened"]):
            if not look and st is None:
                return          # (left over from before: wait for the dials to be put up again)
            self.dial = {"pick": pick, "nums": list(nums), "seen": now, "opened": hint or now}
            self.say("Combination dials: %s. On the %s dial. Up and down change the number, left and "
                     "right pick the dial, A to try it." % (" ".join(map(str, nums)), self.DIAL_NAMES[pick].lower()),
                     interrupt=False)
            return
        st["seen"] = now
        if pick != st["pick"]:
            st["pick"] = pick
            self.say("%s dial, %d" % (self.DIAL_NAMES[pick], nums[pick]), interrupt=True)
        if nums != st["nums"]:
            changed = [k for k in range(3) if nums[k] != st["nums"][k]]
            st["nums"] = list(nums)
            if changed == [pick]:
                self.say(str(nums[pick]), interrupt=True)
            else:
                self.say(" ".join(map(str, nums)), interrupt=True)

    def brake_words(self, st, key=None):
        total, target, n = st["sum"], st["target"], st["count"]
        if key is not None:
            words = "%d put in. Total %d, %d number%s." % (key, total, n, "" if n == 1 else "s")
        else:
            words = "Total %d, %d number%s." % (total, n, "" if n == 1 else "s")
        left = target - total
        if left > 0:
            words += " %d to go." % left
        elif left < 0:
            words += " Over by %d." % -left
        elif n >= 10:
            words += " Done."
        return words

    # -- items --------------------------------------------------------------------------
    GUNS = {3, 4, 5, 6, 7, 8, 9, 10, 11, 17, 19, 22, 23}

    def item_names(self):
        if getattr(self, "_items", None) is None:
            self._items = []
            try:
                exe = self.mem.exe_path()
                if exe:
                    self._items = gmd.texts(os.path.dirname(exe), "message_item_name")
            except Exception:
                logging.exception("item names")
        return self._items

    def items_shown(self):
        """(whose items, slot) the item screen's cursor is on, or None: your own, or your
        partner's while you pick which of theirs to change with."""
        v = self.game.item_view()
        if not v or v[0] not in ("own", "partner"):
            return None
        c = self.game.controlled()
        if not c:
            return None
        if v[0] == "own":
            return c[0], v[1]
        others = [n for n, _ in self.game.characters() if n != c[0]]
        return (others[0], v[1]) if others else None

    def with_equip(self, said, words):
        """On the item screen: ", equipped" after the weapon in hand, and the game's "Equip weapon"
        (shown for both) said as "Un-equip" when the weapon picked is the one in hand."""
        shown = self.items_shown()
        if not shown:
            return said
        who, cur = shown
        eq = self.game.equipped(who)
        if eq is None or eq < 0:
            return said
        if words == "Equip weapon":
            return "Un-equip weapon" if cur == eq else said
        inv = self.game.inventory(who)
        names = self.item_names()
        if eq < len(inv) and 0 < inv[eq][0] < len(names) and names[inv[eq][0]] == words and cur == eq:
            return said + ", equipped"
        return said

    def poll_equip(self):
        """Say when the weapon in hand changes."""
        c = self.game.controlled()
        key = None
        if c:
            eq = self.game.equipped(c[0])
            if eq is not None:
                key = (c[0], eq)
        was = getattr(self, "equip_was", None)
        self.equip_was = key
        if not key or not was or was[0] != key[0] or was[1] == key[1]:
            return
        if key[1] < 0:
            self.say("Weapon unequipped.", interrupt=False)
            return
        inv = self.game.inventory(key[0])
        names = self.item_names()
        item = inv[key[1]][0] if key[1] < len(inv) else 0
        name = names[item] if 0 < item < len(names) else "Weapon"
        self.say("%s equipped." % name, interrupt=False)

    def whose_items(self, said):
        """On the item screen with your partner there, say whose items the cursor is on when that
        changes: Y shows the other one's items (and makes them the one you play), and changing an
        item with your partner has you pick one of their slots ("Billy's items. Knife")."""
        if self.game.item_view() is None:
            self.items_owner = None
            return said
        shown = self.items_shown()
        if not shown or len(self.game.characters()) < 2:
            return said
        was = getattr(self, "items_owner", None)
        self.items_owner = shown[0]
        if was and was != shown[0]:
            return "%s's items. %s" % (shown[0], said)
        return said

    def amount_words(self, words, item, amount):
        if item in self.GUNS:
            return "%s, %d %s" % (words, amount, "round" if amount == 1 else "rounds")
        if amount > 1 or "Ammo" in words or "Grenade" in words:
            return "%s, %d" % (words, amount)
        return words

    def with_amount(self, words):
        """'Handgun' -> 'Handgun, 15 rounds' when it is one of the items you carry (on the item
        screen: the one in the slot the cursor is on, of whoever's items are showing)."""
        names = self.item_names()
        if not names:
            return words
        c = self.game.controlled()
        shown = self.items_shown()
        if shown:
            inv = self.game.inventory(shown[0])
            cur = shown[1]
            if cur < len(inv) and 0 < inv[cur][0] < len(names) and names[inv[cur][0]] == words:
                return self.amount_words(words, inv[cur][0], inv[cur][1])
        order = [w for w, _ in self.game.characters()] or ["Rebecca"]
        if c and c[0] in order:
            order.remove(c[0])
            order.insert(0, c[0])
        for who in order:
            for item, amount in self.game.inventory(who):
                if 0 < item < len(names) and names[item] == words:
                    if item in self.GUNS:
                        return "%s, %d %s" % (words, amount, "round" if amount == 1 else "rounds")
                    if amount > 1 or "Ammo" in words or "Grenade" in words:
                        return "%s, %d" % (words, amount)
                    return words
        return words

    # -- controller keys ---------------------------------------------------------------------
    def health_words(self):
        """'Rebecca: Fine. Health 100 percent.' for each character in the game."""
        out = []
        for name, obj in self.game.characters():
            h = self.game.health(obj)
            if not h:
                continue
            hp, top = h
            ratio = min(1.0, hp / float(top))
            if hp == 0:
                word = "Dead"
            elif ratio > 0.66:
                word = "Fine"
            elif ratio > 0.33:
                word = "Caution"
            else:
                word = "Danger"
            out.append("%s: %s. Health %d percent." % (name, word, round(ratio * 100)))
        if not out:
            return "Not in the game."
        if len(out) == 1:
            return out[0].split(": ", 1)[1]
        return " ".join(out)

    def poll_death(self):
        """Say when a character dies (the game over screen is a picture)."""
        dead = set()
        for name, obj in self.game.characters():
            h = self.game.health(obj)
            if h and h[0] == 0:
                dead.add(name)
        for name in dead - getattr(self, "dead_seen", set()):
            self.say("%s has died." % name, interrupt=True)
        self.dead_seen = dead

    def run(self):
        self.say("Resident Access 0, version %s. Waiting for the game." % VERSION)
        while True:
            if told_to_quit(self.quit_event):
                logging.info("a newer copy has started: closing")
                self.link.release()
                os._exit(4)
            self.link.push()
            if not self.mem.connect():
                if self.connected:
                    self.say("The game has closed.")
                    self.connected = False
                    self.scene = None
                    self.pad_state = None
                    self.pad_tries = 0
                time.sleep(1.0)
                continue
            if not self.connected:
                self.connected = True
                self.text_quiet_until = time.monotonic() + 2.0
                self.say("Resident Access 0 ready.")
            try:
                self.poll_pad_fix()
                self.poll_room()
                self.poll_title()
                self.poll_text()
                self.poll_death()
                self.poll_controller()
                self.poll_offset()
                self.poll_walk()
                self.poll_ledge()
                self.poll_push()
                self.poll_taken()
                self.poll_partner()
                self.poll_modmenu()
                self.poll_enemies()
                self.poll_item_screen()
                self.poll_examine()
                self.poll_equip()
                self.poll_files()
                self.poll_choice()
                self.poll_clock()
                self.poll_hold()
                self.poll_save()
                self.poll_load_choice()
                self.poll_brake()
                self.poll_dial()
            except NotReady:
                pass
            except Exception:
                logging.exception("poll")
            time.sleep(0.05)


def other_copies():
    """Windows and processes of other copies of the mod: [(pid, name)]."""
    import subprocess
    ps = ("Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(cmd|py|pyw|python|pythonw)\\.exe$' } | "
          "ForEach-Object { '{0}|{1}|{2}|{3}' -f $_.ProcessId, $_.ParentProcessId, $_.Name, $_.CommandLine }")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                             timeout=20, creationflags=0x08000000).stdout
    except Exception:
        logging.exception("listing processes")
        return []
    procs = {}
    for line in out.splitlines():
        parts = line.split("|", 3)
        if len(parts) == 4 and parts[0].isdigit() and parts[1].isdigit():
            procs[int(parts[0])] = (int(parts[1]), parts[2].lower(), parts[3])
    mine, p = set(), os.getpid()
    while p in procs and p not in mine:
        mine.add(p)
        p = procs[p][0]
    mine.add(p)
    found = []
    for pid, (ppid, name, cmd) in procs.items():
        if pid in mine:
            continue
        low = cmd.lower()
        if (name == "cmd.exe" and "start resident access 0.bat" in low) or \
                (name != "cmd.exe" and "re0access" in low and "dev_runner" not in low):
            found.append((pid, name))
    return found


def take_over():
    """Close every other copy of the mod, and their windows, so only this one speaks."""
    import subprocess
    k32 = ctypes.WinDLL("kernel32")
    k32.CreateEventW.restype = ctypes.c_void_p
    ev = k32.CreateEventW(None, True, False, QUIT_EVENT)
    k32.SetEvent(ctypes.c_void_p(ev))
    time.sleep(1.5)
    k32.ResetEvent(ctypes.c_void_p(ev))
    for pid, name in other_copies():
        logging.info("closing old copy: %s %d", name, pid)
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True,
                       creationflags=0x08000000)
    return ev


def told_to_quit(ev):
    if not ev:
        return False
    k32 = ctypes.WinDLL("kernel32")
    return k32.WaitForSingleObject(ctypes.c_void_p(ev), 0) == 0


def start_log():
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    if os.path.exists(LOG):
        try:
            os.replace(LOG, os.path.join(ROOT, "re0access.old.log"))
        except OSError:
            pass
    fh = logging.handlers.RotatingFileHandler(LOG, maxBytes=20 * 1024 * 1024, backupCount=0,
                                              encoding="utf-8", delay=True)
    fh.setFormatter(logging.Formatter("%(asctime)s %(name)s %(message)s"))
    root.addHandler(fh)


def main():
    App.quit_event = take_over()
    start_log()
    logging.info("start %s", VERSION)
    try:
        from . import update
        if update.check(Speech().say):
            logging.info("updated: starting the new version")
            os._exit(update.RESTART)
    except Exception:
        logging.exception("update check")
    try:
        with open(os.path.join(ROOT, "re0access.pid"), "w") as fh:
            fh.write(str(os.getpid()))
    except OSError:
        pass
    try:
        App().run()
    except KeyboardInterrupt:
        pass
